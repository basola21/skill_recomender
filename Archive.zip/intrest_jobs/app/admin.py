from django.contrib import admin
from .models import Skill, Job, Contact, Blog, Profile
admin.site.register(Skill)
admin.site.register(Job)
admin.site.register(Contact)
admin.site.register(Blog)
